# Team Information

**Course:** _[ARTIFICIAL INTELLIGENCE 2023 UPF]_

**Semester:** FIRST TRIMESTER, 2023

**Instructor:** _[SERGIO CALO OLIVEIRA]_

**Team name:** _[IsaacPacmanov]_

**Team members:**

* U162359 - Dorian Erazo Orozco - dorianemmanuel.erazo01@estudiant.upf.edu - DorianErazo
